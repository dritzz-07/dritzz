import { motion } from 'motion/react';
import { Calendar, CreditCard, Car, Sparkles } from 'lucide-react';

const steps = [
  {
    icon: Calendar,
    title: 'Book Online',
    desc: 'Choose your package, pick a date and time that suits you, and fill in your details.'
  },
  {
    icon: CreditCard,
    title: 'Pay Securely',
    desc: 'Complete your payment instantly via UPI, card, or net banking.'
  },
  {
    icon: Car,
    title: 'We Arrive',
    desc: 'Our trained team arrives at your doorstep at your scheduled time with all equipment.'
  },
  {
    icon: Sparkles,
    title: 'Drive Spotless',
    desc: 'Enjoy your freshly detailed car. We clean up everything before we leave.'
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-black px-6 md:px-16 py-24 border-t border-white/5">
      <div className="section-label">Simple Process</div>
      <h2 className="section-title">HOW IT WORKS?</h2>
      <p className="text-neutral-400 max-w-md mb-16 uppercase tracking-wider">FOUR EASY STEPS TO A SPOTLESS CAR — WITHOUT LEAVING YOUR HOME.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
        {steps.map((step, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className="flex flex-col gap-4"
          >
            <div className="w-12 h-12 rounded bg-white/5 flex items-center justify-center border border-white/10">
              <step.icon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase tracking-wider mb-2 text-white">{step.title}</h3>
              <p className="text-sm text-neutral-500 leading-snug">{step.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
